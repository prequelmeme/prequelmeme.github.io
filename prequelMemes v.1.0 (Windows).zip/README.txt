Hello there!

It's a suprise to be sure (but a welcome one) to see your here!
This program is very simple: just double click the "prequelMemes.exe" file, enter a quote, press "Enter" and see what happens!

COMMON COMMANDS (without quotation marks):
Type "i" or "info" for instructions
Type "e" or "exit" to exit the program
Type "c" or "credits" to see the credits

Please do not use any exclamation marks (!), question marks (?), apostrophes ('), commas (,) or dots (.) etc. in your inputs.

Made by u/YSBjdW50
Thanks to u/PhantomAlpha01 for the help