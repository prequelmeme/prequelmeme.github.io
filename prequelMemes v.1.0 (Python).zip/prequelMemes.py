print("Prequel quote program")
print("Version: 1.0")
print(" ")
print("i - instructions")
print("c - credits")
print("e - exit the program")

while True:
	print("")
	print("Insert a quote:")
	x = input()
	quote = x.lower()
	print(" ")

	if quote == "i" or quote == "info" or quote == "instructions":
		print("INSTRUCTIONS:")
		print("Hello there, thank you for using this program!")
		print("This program is very simple. You write a prequel quote and the program answers with an appropriate response")
		print("For example: if you write 'Hello there', the program responds with: 'General Kenobi! You're a bold one!'")
		print("This program IS NOT case sensitive. Writing 'hello there' yields the same result as 'HELLO THERE'")
		print("DO NOT use exclamation marks (!), question marks (?), apostrophes ('), commas (,) dots (.) etc. in your inputs")
		print(" ")
		print("Write 'c' for credits")
		print("Write 'e' to exit the program")
		print(" ")
		print("In its current version, the program features quotes from Episodes 1, 2 and 3.")
		print("I'm planning to add quotes from all prequels (like Clone Wars cartoons and Rogue one) in the future.")
		print(" ")
		print("Feedback is appreciated!")
		print("Thanks for reading, may the force be with you!")

	elif quote == "c" or quote == "credits":
		print("CREDITS:")
		print("Made by u/YSBjdW50")
		print("Thanks also to u/PhantomAlpha01")
		print("Coded in Python 3.5.2")
		print("Version: 1.0")

	elif quote == "e" or quote == "exit":
		print("Goodbye - may the Force be with you!")
		exit()

	elif quote == "you were right about one thing master" or quote == "negotiations":
		print("The negotiations were short")

	elif quote == "the negotiations were short" or quote == "negotiations were short":
		print("*awkward stare from Qui-Gon*")

	elif quote == "the ability to speak":
		print("... does not make you intelligent.")

	elif quote == "a bigger fish" or quote == "theres always a bigger fish" or quote == "there is always a bigger fish":
		print("There's always a bigger fish")

	elif quote == "my lord is that legal" or quote == "is that legal":
		print("I will make it legal!")

	elif quote == "that doesnt compute" or quote == "that does not compute":
		print("Uh, wait, uh, you're under arrest!")

	elif quote == "credits will do fine":
		print("No, they won't!")

	elif quote == "a suprise to be sure" or quote == "suprise to be sure":
		print("...but a welcome one.")

	elif quote == "who was the father" or quote == "who is the father" or quote == "who is your daddy":
		print("There was no father...")
		print("Spoiler: it was Palpatine")

	elif quote == "are you an angel" or quote == "angel":
		print("An angel. I've heard the deep space pilots talk about them. They are the most beautiful creatures in the universe. They live on the Moons of Iego I think.")
		print("Padme looks at him, not knowing what to say.")

	elif quote == "youre a pilot" or quote == "you are a pilot":
		print("All my life!")

	elif quote == "this is getting out of hand":
		print("Now there are two of them!")

	elif quote == "spinning" or quote == "good trick":
		print("I'll try spinning, that's a good trick!")

	elif quote == "podracing":
		print("Now this is podracing!")

	elif quote == "now this is podracing" or quote == "this is podracing":
		print("*Anakin thinks battle = podracing*")
		print("*Little Anakin might be retarded*")

	elif quote == "rule of two" or quote == "always two there are" or quote == "always 2 there are" or quote == "rule of 2" or quote == "number of genders":
		print("Always two there are, no more, no less. A master and an apprentice.")
		print("But which was destroyed: the master or the apprentice?")

	elif quote == "i guess i was wrong":
		print("There was no danger at all.")

	elif quote == "there was no danger at all" or quote == "no danger at all":
		print("*The fucking ship blows up*")
		print("¯\_(ツ)_/¯")

	elif quote == "you wanna buy some deathsticks" or quote == "wanna buy some deathsticks" or quote == "you wanna buy some death sticks" or quote == "wanna buy some death sticks" or quote == "death sticks" or quote == "deathsticks" or quote == "mind trick":
		print(" - You wanna buy some death sticks?")
		print(" - You don't want to sell me death sticks.")
		print(" - I don't wanna sell you death sticks.")
		print(" - You want to go home and rethink your life.")
		print(" - I wanna go home and rethink my life.")

	elif quote == "boba is your father here" or quote == "yep":
		print("Yep.")

	elif quote == "your clones are very impressive you must be very proud" or quote == "your clones are very impressive":
		print("i'm just a simple man trying to make my way in the universe")

	elif quote == "i dont like sand" or quote == "sand":
		print("It's coarse and rough and irritating... and it gets everywhere.")
		print("*Creep mode activated*")

	elif quote == "i love democracy":
		print("I love the Republic")
		print("Note: smoothest speech ever")

	elif quote == "put the ship down":
		print("No Anakin! You'll be expelled from the Jedi order")

	elif quote == "i see it" or quote == "easy" or quote == "oh this is going to be easy":
		print("Oh, this is going to be easy.")

	elif quote == "this is where the fun begins" or quote == "the fun begins" or quote == "sister walks into your room":
		print("This is where the fun begins!")
		print("*the fun begins*")

	elif quote == "flying is for droids":
		print("*Beep Beep*")

	elif quote == "you are no match for him he is a sith lord" or quote == "youre no match for him hes a sith lord" or quote == "hes a sith lord":
		print("Chancellor Palpatine, Sith Lords are our speciality.")

	elif quote == "ive been looking forward to this" or quote == "i have been looking forward to this":
		print("My powers have doubled since the last time we met, Count.")

	elif quote == "my powers have doubled since the last time we met count" or quote == "twice the pride" or quote == "twice the pride double the fall":
		print("Good. Twice the pride, double the fall.")

	elif quote == "good anakin" or quote == "kill him now" or quote == "kill him":
		print("Good Anakin!")
		print("Kill him. Kill him now.")

	elif quote == "do it":
		print("*anakin does it, what an absolute madlad*")

	elif quote == "it is not the jedi way" or quote == "its not the jedi way" or quote == "not the jedi way":
		print("It is only natural. He cut off your arm, and you wanted revenge.")

	elif quote == "wait a minute how did this happen" or quote == "how did this happen":
		print("We're smarter than this.")

	elif quote == "youre shorter than i expected" or quote == "you are shorter than i expected" or quote == "general grievous" or quote == "grievous":
		print("Jedi scum!")

	elif quote == "your lightsabers will make a fine addition to my collection" or quote == "fine addition" or quote == "fine addition to my collection":
		print("*Grievous takes the lightsabers like a boss*")

	elif quote == "time to abandon ship":
		print("*Grievous abandons ship like a total madlad*")

	elif quote == "we lost something" or quote == "half a ship" or quote == "we are still flying half a ship":
		print("Not to worry, we are still flying half a ship.")

	elif quote == "another happy landing":
		print("*Obi-Wan lands again happily*")

	elif quote == "you are on this council":
		print("But we do not grant you the rank of master.")

	elif quote == "this is outrageous" or quote == "outrageous":
		print("It's unfair. How can you be on the council and not be a master?")

	elif quote == "how can you be on the council and not be a master" or quote == "motherfucker" or quote == "whine" or quote == "how can you be on the council":
		print("Take a seat, young Skywalker.")

	elif quote == "we do not have many ships to spare":
		print("What about the droid attack on the Wookiees?")

	elif quote == "what about the droid attack on the wookiees" or quote == "droid attack on the wookiees" or quote == "wookiees":
		print("He's right. It's a system we cannot afford to lose.")

	elif quote == "did you ever hear the tragedy of darth plagueis the wise" or quote == "darth plagueis the wise" or quote == "tragedy of darth plagueis the wise" or quote == "have you ever heard the tragedy of darth plagueis the wise":
		print(" I thought not. It's not a story the Jedi would tell you. It's a Sith legend. Darth Plagueis was a Dark Lord of the Sith, so powerful and so wise he could use the Force to influence the midichlorians to create life... He had such a knowledge of the dark side that he could even keep the ones he cared about from dying. The dark side of the Force is a pathway to many abilities some consider to be unnatural. He became so powerful... the only thing he was afraid of was losing his power, which eventually, of course, he did. Unfortunately, he taught his apprentice everything he knew, then his apprentice killed him in his sleep. It's ironic he could save others from death, but not himself")

	elif quote == " its ironic" or quote == "ironic":
		print("He could save others from death... but not himself")

	elif quote == "is it possible to learn this power":
		print("Not from a jedi.")

	elif quote == "hello there":
		print("General Kenobi! You're a bold one!")

	elif quote == "general kenobi":
		print("You're a bold one")

	elif quote == "your move":
		print("You fool. I've been trained in your Jedi arts by Count Dooku.")
		print("*Grievous spins his sabers like an absolute wanker*")

	elif quote == "you fool" or quote == "ive been trained in your jedi arts by count dooku":
		print("*Grievous ignites and spins his sabers like an absolute wanker*")

	elif quote == "army or not you must realize you are doomed" or quote == "army or not you must realise you are doomed" or quote == "you are doomed" or quote == "army or not":
		print("Oh I dont think so")

	elif quote == "oh i dont think so":
		print("*HNNGGH!*")

	elif quote == "are you going to kill me":
		print("I would certainly like to.")

	elif quote == "in the name of the galactic senate of the republic" or quote == "under arrest":
		print("You're under arrest, Chancellor.")

	elif quote == "the senate will decide your fate":
		print("I AM THE SENATE.")

	elif quote == "i am the senate":
		print("Not yet!")

	elif quote == "not yet":
		print("It's treason then.")

	elif quote == "its treason then" or quote == "it is treson then" or quote == "treson":
		print("*Autistic screaming*")

	elif quote == "no no no you will die" or quote == "you will die":
		print("*Windu deflects lightning like a fucking boss*")

	elif quote == "ur mom gey" or quote == "ur mom gay" or quote == "ur mum gey" or quote == "ur mum gay":
		print("no u")

	elif quote == "unlimited power":
		print("UNLIMITED... POWAAAAAA")
		print("*Windu flies out of the window*")

	elif quote == "commander cody the time has come" or quote == "order 66" or quote == "66":
		print("Execute order 66.")

	elif quote == "execute order 66":
		print("Yes my lord.")

	elif quote == "master skywalker there are too many of them" or quote == "what are we going to do":
		print("What are we going to do? (RIP younglings)")

	elif quote == "the attempt on my life":
		print("...has left me scarred and deformed.")

	elif quote == "the republic will be reorganized":
		print("... into the frst Galactic Empire! For a safe and secure society.")

	elif quote == "so this is how liberty dies" or quote == "how liberty dies":
		print("With thunderous applause.")

	elif quote == "thunderous applause":
		print("So this is how liberty dies... With thunderous applause.")

	elif quote == "you turned her against me":
		print("You have done that yourself.")

	elif quote == "you have become the very thing you swore to destroy" or quote == "dont lecture me obiwan" or quote == "i see through the lies of the jedi" or quote == "the lies of the jedi":
		print("Don't lecture me, Obi-Wan. I see through the lies of the Jedi. I do not fear the dark side as you do.")

	elif quote == "dont make me kill you" or quote == "my allegiance" or quote == "democracy":
		print("Anakin, my allegiance is to the Republic, to DEMOCRACY!")

	elif quote == "only a sith deals in absolutes" or quote == "absolutes" or quote == "if youre not with me then youre my enemy":
		print("Only a sith deals in absolutes. I will do what I must.")

	elif quote == "i will do what i must":
		print("You will try...")

	elif quote == "anakin chancellor palpatine is evil" or quote == "palpatine is evil" or quote == "the jedi are evil":
		print("From my point of view, the Jedi are evil!")

	elif quote == "from my point of view the jedi are evil":
		print("Well then you are lost!")

	elif quote == "its over anakin":
		print("I have the high ground!")

	elif quote == "i have the high ground" or quote == "the high ground" or quote == "high ground":
		print("You underestimate my power!")

	elif quote == "you underestimate my power":
		print("Don't try it!")

	elif quote == "dont try it":
		print("*Anakin tries it like a little bitch*")

	elif quote == "you were the chosen one":
		print("You were the Chosen One! You were supposed to destroy the Sith, not join them. You were supposed to bring balance to the force, not leave it in darkness.")

	elif quote == "i hate you":
		print("You were my brother, Anakin! I loved you.")
		print("Note: that's gay")

	elif quote == "you were my brother i loved you" or quote == "my brother" or quote == "you were my brother":
		print("I loved you!")
		print("Note: that's gay")

	elif quote == "we were on the verge of greatness":
		print("We were this close!")

	elif quote == "sector is clear":
		print("NOT CLEAR, NOT CLEAR!")

	else:
		print("*Visible confusion* There might have been a typo... try again!")